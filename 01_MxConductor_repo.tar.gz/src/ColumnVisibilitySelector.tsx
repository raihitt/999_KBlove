import React from 'react';
import { Box, FormControlLabel, Checkbox, Button, Popover } from '@mui/material';

interface ColumnVisibilitySelectorProps {
  headers: string[];
  visible: Record<string, boolean>;
  onChange: (header: string, visible: boolean) => void;
}

const ColumnVisibilitySelector: React.FC<ColumnVisibilitySelectorProps> = ({ headers, visible, onChange }) => {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
      <Button variant="outlined" size="small" onClick={handleClick} style={{ marginBottom: 8 }}>
        列の表示/非表示
      </Button>
      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <Box p={2}>
          {headers.map(header => (
            <FormControlLabel
              key={header}
              control={
                <Checkbox
                  checked={visible[header] !== false}
                  onChange={(_, checked) => onChange(header, checked)}
                  size="small"
                />
              }
              label={header}
            />
          ))}
        </Box>
      </Popover>
    </>
  );
};

export default ColumnVisibilitySelector;
