import type { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import path from 'path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const SETTINGS_PATH = path.join(DATA_DIR, 'point_settings.json');

const getSettingsPath = (filename?: string) => {
  if (!filename) return SETTINGS_PATH;
  // ファイル名に不正文字が含まれていないか簡易チェック
  const safeName = filename.replace(/[^a-zA-Z0-9_\-\.]/g, '');
  return path.join(DATA_DIR, safeName.endsWith('.json') ? safeName : safeName + '.json');
};

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const filename = req.query.filename || req.body?.filename;
  const settingsPath = getSettingsPath(typeof filename === 'string' ? filename : Array.isArray(filename) ? filename[0] : undefined);
  if (req.method === 'POST') {
    try {
      if (!req.body || Object.keys(req.body).length === 0) {
        res.status(400).json({ ok: false, error: 'Empty settings not saved', path: settingsPath });
        return;
      }
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      // filenameがbodyに含まれている場合は除外して保存
      const { filename: _filename, ...saveBody } = req.body;
      fs.writeFileSync(settingsPath, JSON.stringify(saveBody, null, 2), 'utf-8');
      res.status(200).json({ ok: true, path: settingsPath });
    } catch (e) {
      res.status(500).json({ ok: false, error: String(e), path: settingsPath });
    }
    return;
  }
  if (req.method === 'GET') {
    try {
      if (!fs.existsSync(settingsPath)) {
        res.status(200).json({ ok: true, data: {}, path: settingsPath });
        return;
      }
      const data = fs.readFileSync(settingsPath, 'utf-8');
      res.status(200).json({ ok: true, data: JSON.parse(data), path: settingsPath });
    } catch (e) {
      res.status(500).json({ ok: false, error: String(e), path: settingsPath });
    }
    return;
  }
  res.status(405).end();
}
