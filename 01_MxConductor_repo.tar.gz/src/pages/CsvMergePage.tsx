import React, { useState } from 'react';
import Papa from 'papaparse';
import { Container, Typography, Box, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Alert, LinearProgress } from '@mui/material';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import DownloadIcon from '@mui/icons-material/Download';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

// コード列名（日本語CSVの想定）
const CODE_COLUMN = 'コード';

function mergeCsvRows(csvArrays: Record<string, string | number>[][]): { merged: Record<string, string | number>[]; headers: string[] } {
  const mergedMap: Record<string, Record<string, string | number>> = {};
  const allHeaders = new Set<string>();
  for (const rows of csvArrays) {
    for (const row of rows) {
      if (!row || Object.values(row).every(v => v === undefined || v === null || v === '')) continue;
      const code = row[CODE_COLUMN];
      if (!code) continue;
      if (!mergedMap[code as string]) mergedMap[code as string] = { [CODE_COLUMN]: code };
      Object.entries(row).forEach(([k, v]) => {
        if (k !== CODE_COLUMN) mergedMap[code as string][k] = v;
        allHeaders.add(k);
      });
    }
  }
  const headers = [CODE_COLUMN, ...Array.from(allHeaders).filter(h => h !== CODE_COLUMN)];
  const merged = Object.values(mergedMap);
  return { merged, headers };
}

// ファイルごとにUTF-8→SJISの順でパース
async function parseCsvWithEncoding(file: File): Promise<Record<string, string | number>[]> {
  // 1. UTF-8でパース
  let text = await file.text();
  let parsed = Papa.parse<Record<string, string | number>>(text, { header: true, skipEmptyLines: true });
  let filtered = parsed.data.filter(row => row && Object.values(row).some(v => v !== undefined && v !== null && v !== ''));
  // 2. データが空 or 1行目に「」が多い場合はSJIS再パース
  const isCorrupted = filtered.length === 0 || (Object.values(parsed.data[0] || {}).join('').match(/�/g)?.length ?? 0) > 2;
  if (isCorrupted) {
    try {
      const iconv = await import('iconv-lite');
      const buf = await file.arrayBuffer();
      text = iconv.decode(Buffer.from(buf), 'shift_jis');
      parsed = Papa.parse<Record<string, string | number>>(text, { header: true, skipEmptyLines: true });
      filtered = parsed.data.filter(row => row && Object.values(row).some(v => v !== undefined && v !== null && v !== ''));
    } catch {
      // SJISパース失敗時はそのまま
    }
  }
  return filtered;
}

const CsvMergePage: React.FC = () => {
  const [mergedRows, setMergedRows] = useState<Record<string, string | number>[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // 仮説推論検証モデル: UTF-8→SJIS順でパース
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const files = e.target.files;
    if (!files) return;
    setLoading(true);
    try {
      const allRows: Record<string, string | number>[][] = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const filtered = await parseCsvWithEncoding(file);
        if (filtered.length === 0) throw new Error(`${file.name} の内容が空か、文字化けしています`);
        allRows.push(filtered);
      }
      const { merged, headers } = mergeCsvRows(allRows);
      setMergedRows(merged);
      setHeaders(headers);
    } catch (e: any) {
      setError(e.message || 'CSVの読み込みに失敗しました');
    } finally {
      setLoading(false);
    }
  };

  // CSVダウンロード（UTF-8固定）
  const handleDownload = () => {
    const csv = Papa.unparse(mergedRows, { columns: headers });
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'merged.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Container maxWidth="md" sx={{ py: 6 }}>
      <Box mb={3} display="flex" alignItems="center" gap={2}>
        <Button
          variant="outlined"
          color="primary"
          startIcon={<ArrowBackIcon />}
          href="/"
          size="large"
          sx={{ fontWeight: 'bold', borderRadius: 2, boxShadow: 1 }}
        >
          メインダッシュボードへ戻る
        </Button>
        <Typography variant="h4" fontWeight="bold" gutterBottom color="primary.main" sx={{ flex: 1, ml: 2 }}>
          CSVマージツール
        </Typography>
      </Box>
      <Typography variant="subtitle1" color="text.secondary" mb={3}>
        複数のCSVファイルをアップロードし、「コード」列で横に統合します。<br />
        ※自動でUTF-8/SJISを判定します。
      </Typography>
      <Box mb={3} display="flex" alignItems="center" gap={2}>
        <input
          id="csv-upload"
          type="file"
          multiple
          accept=".csv,text/csv"
          style={{ display: 'none' }}
          onChange={handleFileChange}
        />
        <label htmlFor="csv-upload">
          <Button variant="contained" color="primary" component="span" startIcon={<UploadFileIcon />} disabled={loading} size="large">
            CSVファイルを選択（複数可）
          </Button>
        </label>
        {mergedRows.length > 0 && (
          <Button variant="outlined" color="success" startIcon={<DownloadIcon />} sx={{ ml: 1 }} onClick={handleDownload} size="large">
            マージ結果をCSVで保存
          </Button>
        )}
      </Box>
      {loading && <LinearProgress sx={{ mb: 2 }} />}
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {mergedRows.length > 0 && headers.length > 0 && (
        <TableContainer component={Paper} sx={{ maxHeight: 500, borderRadius: 2, boxShadow: 2 }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                {headers.map(h => <TableCell key={h} sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>{h}</TableCell>)}
              </TableRow>
            </TableHead>
            <TableBody>
              {mergedRows.map((row, idx) => (
                <TableRow key={idx}>
                  {headers.map(h => <TableCell key={h}>{row[h]}</TableCell>)}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Container>
  );
};

export default CsvMergePage;