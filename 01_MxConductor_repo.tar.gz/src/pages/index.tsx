import * as React from 'react';
import Papa from 'papaparse';
import { Container, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Box, Button, Dialog, DialogTitle, DialogContent, DialogActions, Snackbar, CircularProgress, TextField } from '@mui/material';
import ColumnVisibilitySelector from '../ColumnVisibilitySelector';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import Link from '@mui/material/Link';
import MergeTypeIcon from '@mui/icons-material/MergeType';
// import { Link as RouterLink } from 'react-router-dom'; // ← react-router-domが未インストールの場合は依存追加が必要

type CsvRow = Record<string, string | number>;

function parseCsvText(text: string): CsvRow[] {
  const result = Papa.parse<any>(text, { header: true, skipEmptyLines: true });
  return result.data.map(row => ({
    ...row,
  }));
}

// CSV行の各値を自動的に数値型へ変換
function autoConvertRow(row: Record<string, any>): Record<string, string | number> {
  const converted: Record<string, string | number> = {};
  for (const key in row) {
    const num = Number(row[key]);
    converted[key] = !isNaN(num) && row[key] !== '' ? num : row[key];
  }
  return converted;
}

// CSVパース共通化（エンコーディング指定可）
const parseCsvData = (text: string): { headers: string[], rows: CsvRow[] } => {
  const result = Papa.parse<any>(text, { header: true, skipEmptyLines: true });
  const headers = result.meta?.fields ?? [];
  const rows = result.data.map(autoConvertRow);
  return { headers, rows };
};

// 文字化け判定（が多い、またはヘッダーが少ない/空）
function isCorruptedCsv(headers: string[], rows: CsvRow[]): boolean {
  if (headers.length === 0) return true;
  if (rows.length === 0) return true;
  const joined = Object.values(rows[0] || {}).join('');
  if ((joined.match(/�/g) || []).length > 1) return true;
  return false;
}

// PT加算対象外のprefixリスト
const EXCLUDE_PT_PREFIXES = [
  'コード',
  '会社名',
  '市場',
  '業種',
  '[基本項目]直近終値'
];
function isPtTarget(header: string, rows: CsvRow[]): boolean {
  if (EXCLUDE_PT_PREFIXES.some(prefix => header.startsWith(prefix))) return false;
  // 全行で空・null・undefinedなら加算対象外
  return rows.some(row => row[header] !== '' && row[header] !== null && row[header] !== undefined);
}

const EditRecommendDialog: React.FC<{
  open: boolean;
  onClose: () => void;
  headers: string[];
  settings: Record<string, { direction: 'up' | 'down', point: number }>;
  setSettings: React.Dispatch<React.SetStateAction<Record<string, { direction: 'up' | 'down', point: number }>>>;
  onSave?: (settings: Record<string, { direction: 'up' | 'down', point: number }>, filename?: string) => Promise<void>;
  loading?: boolean;
  rawRows: CsvRow[];
}> = ({ open, onClose, headers, settings, setSettings, onSave, loading, rawRows }) => {
  const [local, setLocal] = React.useState(settings);
  const [filename, setFilename] = React.useState('');
  const [loadFilename, setLoadFilename] = React.useState('');
  React.useEffect(() => { setLocal(settings); }, [settings]);
  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>おすすめPT加算設定 編集</DialogTitle>
      <DialogContent>
        <Box display="flex" flexDirection="column" gap={1}>
          {headers.filter(header => isPtTarget(header, rawRows)).map(header => (
            <Box key={header} display="flex" alignItems="center" gap={2}>
              <span style={{ minWidth: 120 }}>{header}</span>
              <select
                value={local[header]?.direction ?? 'up'}
                onChange={e => {
                  const v = e.target.value as 'up' | 'down';
                  setLocal(prev => ({ ...prev, [header]: { ...prev[header], direction: v } }));
                }}
              >
                <option value="up">上で加点</option>
                <option value="down">下で加点</option>
              </select>
              <input
                type="number"
                value={local[header]?.point ?? 0}
                min={0}
                style={{ width: 60 }}
                onChange={e => {
                  const num = Number(e.target.value);
                  setLocal(prev => ({ ...prev, [header]: { ...prev[header], point: num } }));
                }}
              />
            </Box>
          ))}
        </Box>
        <Box mt={2} display="flex" gap={2} alignItems="center">
          <TextField
            size="small"
            label="設定名（ファイル名）"
            value={filename}
            onChange={e => setFilename(e.target.value)}
            placeholder="例: my_settings"
            sx={{ width: 200 }}
          />
          <Button variant="contained" color="primary" disabled={loading || !filename.trim()} onClick={async () => {
            setSettings(local);
            if (onSave) await onSave(local, filename.trim());
            onClose();
          }}>{loading ? <CircularProgress size={20} /> : '名前をつけて保存'}</Button>
          <TextField
            size="small"
            label="読込ファイル名"
            value={loadFilename}
            onChange={e => setLoadFilename(e.target.value)}
            placeholder="例: my_settings"
            sx={{ width: 200 }}
          />
          <Button variant="outlined" color="secondary" disabled={!loadFilename.trim()} onClick={async () => {
            // ファイル名指定でロード
            try {
              const res = await fetch(`/api/settings?filename=${encodeURIComponent(loadFilename.trim())}`);
              const data = await res.json();
              if (data.ok && data.data) {
                setSettings(data.data);
              }
            } catch {}
          }}>ファイル名で読込</Button>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>キャンセル</Button>
        <Button variant="contained" color="primary" disabled={loading} onClick={async () => {
          setSettings(local);
          if (onSave) await onSave(local);
          onClose();
        }}>{loading ? <CircularProgress size={20} /> : '保存'}</Button>
      </DialogActions>
    </Dialog>
  );
};

// --- ここからIndexPage ---

const IndexPage: React.FC = () => {
  // Snackbar（トースト通知）
  const [snackbar, setSnackbar] = React.useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({ open: false, message: '', severity: 'success' });
  // おすすめ設定保存ローディング
  const [savingRecommend, setSavingRecommend] = React.useState(false);
  const [editRecommendOpen, setEditRecommendOpen] = React.useState(false);
  const [userPointSettings, setUserPointSettings] = React.useState<Record<string, { direction: 'up' | 'down', point: number }>>({});
  const [settingsOpen, setSettingsOpen] = React.useState(false);
  const [stocks, setStocks] = React.useState<(CsvRow & { point: number })[]>([]);
  const [csvHeaders, setCsvHeaders] = React.useState<string[]>([]);
  // おすすめ設定（全列point=0, direction=up）
  const [recommendedSettings, setRecommendedSettings] = React.useState<Record<string, { direction: 'up' | 'down', point: number }>>({});
  // おすすめ設定の初期ロードとuserPointSettingsの初期化
  React.useEffect(() => {
    const fetchSettings = async () => {
      try {
        const res = await fetch('/api/settings');
        const data = await res.json();
        if (data.ok && data.data) {
          setRecommendedSettings(data.data);
          setUserPointSettings(data.data); // サーバ値をuserPointSettingsにも反映
        }
      } catch (e) {
        setSnackbar({ open: true, message: 'おすすめ設定の取得に失敗しました', severity: 'error' });
      }
    };
    fetchSettings();
  }, []);
  // ヘッダー変更時におすすめ設定を補完
  React.useEffect(() => {
    if (csvHeaders.length > 0) {
      setRecommendedSettings(prev => {
        const next: Record<string, { direction: 'up' | 'down', point: number }> = {};
        csvHeaders.forEach(header => {
          next[header] = prev[header] || { direction: 'up', point: 0 };
        });
        return next;
      });
    }
  }, [csvHeaders]);
  const [rawRows, setRawRows] = React.useState<CsvRow[]>([]);
  const [showHeaders, setShowHeaders] = React.useState(true);
  const [sortColumn, setSortColumn] = React.useState<string | null>('point');
  const [sortDirection, setSortDirection] = React.useState<'asc' | 'desc'>('desc');
  const [columnVisibility, setColumnVisibility] = React.useState<Record<string, boolean>>({});
  const [clipboardText, setClipboardText] = React.useState('');

  // CSVヘッダーに合わせてuserPointSettingsの不要なキーを除外
  React.useEffect(() => {
    if (csvHeaders.length === 0) return;
    setUserPointSettings(prev => {
      const next: typeof prev = {};
      csvHeaders.forEach(header => {
        if (prev[header]) next[header] = prev[header];
      });
      return next;
    });
  }, [csvHeaders]);

  // サニタイズ関数: directionは必ず 'up' | 'down' 型にする
  function sanitizePointSettings(obj: any): Record<string, { direction: 'up' | 'down', point: number }> {
    const valid: Record<string, { direction: 'up' | 'down', point: number }> = {};
    for (const key in obj) {
      let direction: 'up' | 'down' = 'up';
      if (obj[key]?.direction === 'up' || obj[key]?.direction === 'down') {
        direction = obj[key].direction;
      }
      if (typeof obj[key]?.point === 'number' || !isNaN(Number(obj[key]?.point))) {
        valid[key] = { direction, point: Number(obj[key].point) };
      }
    }
    return valid;
  }

  // 実際に使う設定値（デフォルト＋ユーザー変更）
  const defaultPointSettings = recommendedSettings; // 以降のロジックはこの変数で一貫
  const mergedPointSettings = React.useMemo(() => {
    const merged: Record<string, { direction: 'up' | 'down', point: number }> = {};
    csvHeaders.forEach(header => {
      if (userPointSettings[header]) {
        merged[header] = userPointSettings[header];
      } else {
        merged[header] = defaultPointSettings[header] || { direction: 'up', point: 1 };
      }
    });
    return merged;
  }, [csvHeaders, userPointSettings, defaultPointSettings]);

  // 各列の中央値を計算し保存
  const [medians, setMedians] = React.useState<Record<string, number>>({});
  React.useEffect(() => {
    if (rawRows.length === 0) return;
    // 各列の中央値を計算
    const newMedians: Record<string, number> = {};
    for (const header of csvHeaders) {
      // 数値だけ抽出
      const nums = rawRows.map(row => row[header]).filter(v => typeof v === 'number' && !isNaN(v as number)) as number[];
      if (nums.length > 0) {
        const sorted = [...nums].sort((a, b) => a - b);
        const mid = Math.floor(sorted.length / 2);
        newMedians[header] = sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
      }
    }
    setMedians(newMedians);
  }, [rawRows, csvHeaders]);

  // ポイント計算・ランキング即時反映（中央値基準）
  React.useEffect(() => {
    if (rawRows.length === 0) return;
    const newStocks = rawRows.map(row => {
      let point = 0;
      for (const header of csvHeaders) {
        const setting = mergedPointSettings[header];
        const value = row[header];
        const median = medians[header];
        if (typeof value === 'number' && typeof median === 'number' && setting) {
          if (setting.direction === 'up') {
            point += value > median ? setting.point : -setting.point;
          } else {
            point += value < median ? setting.point : -setting.point;
          }
        }
      }
      return { ...row, point };
    });
    setStocks(newStocks);
  }, [rawRows, mergedPointSettings, csvHeaders, medians]);

  // クリップボードCSV貼り付け処理（UTF-8→Shift-JIS順でパース）
  const handlePasteCsv = async () => {
    let text = clipboardText;
    let { headers, rows } = parseCsvData(text);
    if (isCorruptedCsv(headers, rows)) {
      // Shift-JIS再パース
      try {
        const iconv = await import('iconv-lite');
        const buf = Buffer.from(text, 'binary');
        text = iconv.decode(buf, 'shift_jis');
        const parsed = parseCsvData(text);
        headers = parsed.headers;
        rows = parsed.rows;
      } catch {}
    }
    if (headers.length > 0 && rows.length > 0 && !isCorruptedCsv(headers, rows)) {
      setCsvHeaders(headers);
      setRawRows(rows);
      setStocks(rows.map(row => ({ ...row, point: 0 })));
      setSnackbar({ open: true, message: 'クリップボードからCSVデータを読み込みました', severity: 'success' });
    } else {
      setSnackbar({ open: true, message: '有効なCSVデータが見つかりませんでした（文字化けの可能性あり）', severity: 'error' });
    }
  };

  // ファイルアップロード時もUTF-8→Shift-JIS順で厳密にパース
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    let allRows: CsvRow[] = [];
    let allHeaders: string[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      // 1. UTF-8でパース
      let text = await file.text();
      let { headers, rows } = parseCsvData(text);
      // 2. 文字化けやデータ欠損があればShift-JIS再パース
      if (isCorruptedCsv(headers, rows)) {
        try {
          const iconv = await import('iconv-lite');
          const buf = await file.arrayBuffer();
          text = iconv.decode(Buffer.from(buf), 'shift_jis');
          const parsed = parseCsvData(text);
          headers = parsed.headers;
          rows = parsed.rows;
        } catch {}
      }
      if (i === 0) allHeaders = headers;
      allRows = allRows.concat(rows);
    }
    if (allHeaders.length > 0 && allRows.length > 0 && !isCorruptedCsv(allHeaders, allRows)) {
      setCsvHeaders(allHeaders);
      setRawRows(allRows);
      setStocks(allRows.map(row => ({ ...row, point: 0 })));
    } else {
      setSnackbar({ open: true, message: 'CSVファイルの読み込みに失敗しました（文字化けの可能性あり）', severity: 'error' });
    }
  };

  // 設定のサーバ自動読み込み
  React.useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/settings');
        if (res.ok) {
          const apiData = await res.json();
          if (apiData && apiData.data && Object.keys(apiData.data).length > 0) {
            setUserPointSettings(sanitizePointSettings(apiData.data));
          }
        }
      } catch (e) {
        console.error('設定取得失敗', e);
      }
    })();
  }, []);

  // ソート済みstocksを作成
  const sortedStocks = React.useMemo(() => {
    if (!sortColumn) return stocks;
    const sorted = [...stocks].sort((a, b) => {
      const aValue = a[sortColumn] ?? 0;
      const bValue = b[sortColumn] ?? 0;
      if (typeof aValue === 'number' && typeof bValue === 'number') {
        return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
      }
      return String(aValue).localeCompare(String(bValue), 'ja');
    });
    return sorted;
  }, [stocks, sortColumn, sortDirection]);

  // JSON保存
  const handleSaveJson = () => {
    const activePointCount = Object.values(mergedPointSettings).filter(x => x.point !== 0).length;
    const data = {
      ranking: sortedStocks,
      pointSettings: mergedPointSettings,
      activePointCount,
    };
    const dataStr = JSON.stringify(data, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ranking.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  // JSON読込
  const handleLoadJson = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];
    const text = await file.text();
    try {
      const json = JSON.parse(text);
      if (json && Array.isArray(json.ranking)) {
        setRawRows(json.ranking.map((row: any) => ({ ...row })));
        setStocks(json.ranking.map((row: any) => ({ ...row })));
        if (json.ranking.length > 0) {
          setCsvHeaders(Object.keys(json.ranking[0]).filter((k: string) => k !== 'point'));
        }
        if (json.pointSettings) {
          setUserPointSettings(json.pointSettings);
        }
        setSnackbar({ open: true, message: 'JSONからランキング・設定を読み込みました', severity: 'success' });
      } else if (Array.isArray(json)) {
        // 旧形式（ランキング配列のみ）
        setRawRows(json.map((row: any) => ({ ...row })));
        setStocks(json.map((row: any) => ({ ...row })));
        if (json.length > 0) {
          setCsvHeaders(Object.keys(json[0]).filter((k: string) => k !== 'point'));
        }
        setSnackbar({ open: true, message: 'JSONからランキングを読み込みました', severity: 'success' });
      } else {
        setSnackbar({ open: true, message: '不正なJSONファイルです', severity: 'error' });
      }
    } catch {
      setSnackbar({ open: true, message: 'JSONの読み込みに失敗しました', severity: 'error' });
    }
  };

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom>高配当ランキングダッシュボード</Typography>
      <Box mb={2} display="flex" gap={2} alignItems="center">
        {/* CSVマージツールへのリンク（プロ品質UI/UX） */}
        <Link href="/CsvMergePage" underline="none" sx={{ display: 'flex', alignItems: 'center' }}>
          <Button variant="contained" color="secondary" startIcon={<MergeTypeIcon />} size="large">
            CSVマージツール
          </Button>
        </Link>
        <Typography variant="body2" color="text.secondary" sx={{ ml: 1 }}>
          複数CSVを「コード」列で統合・保存できる便利ツールはこちら！
        </Typography>
      </Box>
      <Box mb={2} display="flex" gap={2}>
        <input
          id="csv-upload"
          type="file"
          multiple
          accept=".csv,text/csv"
          style={{ display: 'none' }}
          onChange={handleFileChange}
        />
        <label htmlFor="csv-upload">
          <Button variant="contained" component="span">CSVファイルを選択</Button>
        </label>
        {/* JSON保存ボタン */}
        <Button variant="outlined" color="primary" onClick={handleSaveJson}>ランキングをJSONで保存</Button>
        {/* JSON読込ボタン */}
        <input
          id="json-upload"
          type="file"
          accept="application/json,.json"
          style={{ display: 'none' }}
          onChange={handleLoadJson}
        />
        <label htmlFor="json-upload">
          <Button variant="outlined" component="span">JSONファイルを読み込む</Button>
        </label>
        {/* クリップボードCSV貼り付けUI */}
        <Box display="flex" gap={1} alignItems="center">
          <TextField
            size="small"
            placeholder="ここにCSVデータを貼り付け"
            value={clipboardText}
            onChange={e => setClipboardText(e.target.value)}
            sx={{ width: 300 }}
            multiline
            minRows={1}
            maxRows={6}
          />
          <Button variant="contained" onClick={handlePasteCsv} disabled={!clipboardText.trim()}>
            クリップボードから読み込み
          </Button>
        </Box>
      </Box>
      {csvHeaders.length > 0 && (
        <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center" mt={6} mb={4}>
          <Box width="100%" display="flex" flexDirection="row" justifyContent="space-between" alignItems="center" mb={1}>
            <Box display="flex" gap={2}>
              <Button variant="outlined" size="small" onClick={() => {
  // 全てのcsvHeadersに対してdirection/up, point/0でリセット
  const reset: Record<string, { direction: 'up' | 'down', point: number }> = {};
  csvHeaders.forEach(header => {
    reset[header] = { direction: 'up', point: 0 };
  });
  setUserPointSettings(reset);
}}>リセット</Button>
              <Button variant="contained" size="small" color="primary" onClick={() => {
                setUserPointSettings(recommendedSettings);
              }}>おすすめPT加算設定を適用</Button>
              <Button variant="outlined" size="small" color="secondary" onClick={() => {
  if (csvHeaders.length > 0) setEditRecommendOpen(true);
}}>おすすめPT加算設定を編集</Button>
            </Box>
            <ColumnVisibilitySelector
              headers={csvHeaders}
              visible={columnVisibility}
              onChange={(header, visible) => {
                setColumnVisibility(prev => ({ ...prev, [header]: visible }));
              }}
            />
          </Box>
          <Box display="flex" alignItems="center" mb={2}>
            <input
              type="checkbox"
              checked={!showHeaders}
              onChange={() => setShowHeaders(v => !v)}
              id="hide-headers-checkbox"
              style={{ marginRight: 8 }}
            />
            <label htmlFor="hide-headers-checkbox">列情報・設定UIを非表示にする</label>
          </Box>
          {showHeaders && (
            <Box mb={4}>
              <Typography variant="h6" gutterBottom>CSVデータ & ランキング</Typography>
              <TableContainer component={Paper} sx={{ maxWidth: '100%', mb: 2, maxHeight: 700, overflow: 'auto', overflowX: 'auto' }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      {csvHeaders.filter(header => columnVisibility[header] !== false).map(header => {
                        const setting = mergedPointSettings[header];
                        const isPointed = setting && setting.point !== 0;
                        return (
                          <TableCell
                            key={header}
                            style={{
                              cursor: 'pointer',
                              userSelect: 'none',
                              background: isPointed ? 'rgba(25, 118, 210, 0.13)' : undefined,
                              position: 'sticky',
                              top: 0,
                              zIndex: 10
                            }}
                            onClick={() => {
                              if (sortColumn === header) {
                                setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                              } else {
                                setSortColumn(header);
                                setSortDirection('desc');
                              }
                            }}
                          >
                            {header}
                            {isPointed && (
                              <span style={{ marginLeft: 4, fontSize: 11, color: setting.point > 0 ? '#1976d2' : '#e53935', fontWeight: 600 }}>
                                {setting.direction === 'up' ? <ArrowDropUpIcon fontSize="small" style={{ verticalAlign: 'middle' }} /> : <ArrowDropDownIcon fontSize="small" style={{ verticalAlign: 'middle' }} />}
                                {setting.point > 0 ? `+${setting.point}` : `${setting.point}`}
                              </span>
                            )}
                            {sortColumn === header && (
                              sortDirection === 'asc' ? <ArrowDropUpIcon fontSize="small" /> : <ArrowDropDownIcon fontSize="small" />
                            )}
                          </TableCell>
                        );
                      })}
                      <TableCell
                        style={{
                          cursor: 'pointer',
                          userSelect: 'none',
                          background: 'rgba(25, 118, 210, 0.13)',
                          position: 'sticky',
                          top: 0,
                          right: 80,
                          zIndex: 11,
                          fontWeight: 'bold',
                          color: '#1976d2'
                        }}
                        onClick={() => {
                          if (sortColumn === 'point') {
                            setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                          } else {
                            setSortColumn('point');
                            setSortDirection('desc');
                          }
                        }}
                      >
                        ポイント
                        {sortColumn === 'point' && (
                          sortDirection === 'asc' ? <ArrowDropUpIcon fontSize="small" /> : <ArrowDropDownIcon fontSize="small" />
                        )}
                      </TableCell>
                      <TableCell
                        style={{
                          background: 'rgba(25, 118, 210, 0.13)',
                          position: 'sticky',
                          top: 0,
                          right: 0,
                          zIndex: 11,
                          fontWeight: 'bold',
                          color: '#1976d2'
                        }}
                      >順位</TableCell>
                    </TableRow>
                    {/* 中央値表示行 */}
                    <TableRow>
                      {csvHeaders.filter(header => columnVisibility[header] !== false).map(header => (
                        <TableCell key={header} style={{ fontSize: 11, color: '#888', background: '#222' }}>
                          中央値: {medians[header] !== undefined ? Math.floor(Number(medians[header]) * 10) / 10 : '-'}
                        </TableCell>
                      ))}
                      <TableCell style={{ fontSize: 11, color: '#888', background: '#222' }}>-</TableCell>
                      <TableCell style={{ fontSize: 11, color: '#888', background: '#222' }}>-</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {/* データ行 */}
                    {sortedStocks.map((row, idx) => (
                      <TableRow key={idx}>
                        {csvHeaders.filter(header => columnVisibility[header] !== false).map(header => {
                          const setting = mergedPointSettings[header];
                          const pt = setting?.point ?? 0;
                          const direction = setting?.direction;
                          let icon = null, iconColor = '', tooltip = '', pointLabel = '';
                          if (pt !== 0) {
                            if (pt > 0 && direction === 'up') {
                              icon = <ArrowDropUpIcon fontSize="small" style={{ color: '#1976d2', verticalAlign: 'middle' }} />;
                              iconColor = '#1976d2';
                              tooltip = `上で+${pt}点`;
                              pointLabel = `+${pt}`;
                            } else if (pt > 0 && direction === 'down') {
                              icon = <ArrowDropDownIcon fontSize="small" style={{ color: '#e53935', verticalAlign: 'middle' }} />;
                              iconColor = '#e53935';
                              tooltip = `下で+${pt}点`;
                              pointLabel = `+${pt}`;
                            } else if (pt < 0 && direction === 'up') {
                              icon = <ArrowDropUpIcon fontSize="small" style={{ color: '#888', verticalAlign: 'middle' }} />;
                              iconColor = '#888';
                              tooltip = `上で${pt}点（減点）`;
                              pointLabel = `${pt}`;
                            } else if (pt < 0 && direction === 'down') {
                              icon = <ArrowDropDownIcon fontSize="small" style={{ color: '#ff9800', verticalAlign: 'middle' }} />;
                              iconColor = '#ff9800';
                              tooltip = `下で${pt}点（減点）`;
                              pointLabel = `${pt}`;
                            }
                          }
                          return (
                            <TableCell key={header} style={{ position: 'relative', verticalAlign: 'middle', background: (pt !== 0) ? 'rgba(25, 118, 210, 0.07)' : undefined }}>
                              <span style={{ marginRight: icon ? 4 : 0 }}>{row[header]}</span>
                              {icon && (
                                <span title={tooltip} style={{ display: 'inline-flex', alignItems: 'center', marginLeft: 2 }}>
                                  {icon}
                                  <span style={{ fontSize: 11, color: iconColor, marginLeft: 1 }}>{pointLabel}</span>
                                </span>
                              )}
                            </TableCell>
                          );
                        })}
                        <TableCell style={{ fontWeight: 'bold', color: '#1976d2', background: 'rgba(25, 118, 210, 0.07)', position: 'sticky', right: 80, zIndex: 2 }}>{row.point}</TableCell>
                        <TableCell style={{ fontWeight: 'bold', color: '#1976d2', background: 'rgba(25, 118, 210, 0.07)', position: 'sticky', right: 0, zIndex: 2 }}>{idx + 1}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          )}
        </Box>
      )}
      <EditRecommendDialog
        open={editRecommendOpen}
        onClose={() => setEditRecommendOpen(false)}
        headers={csvHeaders}
        settings={recommendedSettings}
        setSettings={setRecommendedSettings}
        onSave={async (settings, filename) => {
          setSavingRecommend(true);
          try {
            // PT加算対象のみ抽出
            const filtered = Object.fromEntries(Object.entries(settings).filter(([k]) => isPtTarget(k, rawRows)));
            const res = await fetch('/api/settings', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(filename ? { ...filtered, filename } : filtered),
            });
            if (!res.ok) throw new Error('保存失敗');
            setRecommendedSettings(filtered);
            setUserPointSettings(filtered);
            setSnackbar({ open: true, message: 'おすすめPT設定を保存しました', severity: 'success' });
          } catch (e) {
            setSnackbar({ open: true, message: 'おすすめPT設定の保存に失敗しました', severity: 'error' });
          } finally {
            setSavingRecommend(false);
          }
        }}
        loading={savingRecommend}
        rawRows={rawRows}
      />
    </Container>
  );
};
export default IndexPage;
